influenceDiag <- function(model, approx = F) {
  UseMethod('influenceDiag') }
