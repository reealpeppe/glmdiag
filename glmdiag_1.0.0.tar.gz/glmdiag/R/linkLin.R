linkLin <- function(model, smooth = T, xlab, ylab, title, points.size, points.col) {
  UseMethod('linkLin')
}


